import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ExternalLink, ArrowLeft, Users, Calendar, FileText, Play } from 'lucide-react';

const PlatformPage: React.FC = () => {
  const { platformId } = useParams<{ platformId: string }>();

  // This would typically fetch data based on the platformId
  // For now, we'll use mock data
  const platformData = {
    fechannel: {
      name: 'FE Channel',
      domain: 'FEChannel.com',
      description: 'Premium video streaming platform featuring documentaries, live streams, and educational content.',
      url: 'https://fechannel.com',
      category: 'Media & Broadcasting',
      features: ['24/7 Live Streaming', 'On-Demand Videos', 'Documentary Series', 'Community Features'],
      stats: { users: '8,500+', content: '1,200+ Hours', rating: '4.8/5' }
    },
    // Add more platforms as needed
  };

  const platform = platformData[platformId as keyof typeof platformData];

  if (!platform) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Platform Not Found</h1>
          <p className="text-gray-600 mb-8">The platform you're looking for doesn't exist or has been moved.</p>
          <Link to="/" className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium transition-colors">
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link to="/" className="inline-flex items-center space-x-2 text-red-600 hover:text-red-800 transition-colors">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Hub</span>
          </Link>
        </div>
      </div>

      {/* Platform Header */}
      <section className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">{platform.name}</h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">{platform.description}</p>
            <a
              href={platform.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-colors"
            >
              <span>Visit {platform.name}</span>
              <ExternalLink className="h-5 w-5" />
            </a>
          </div>
        </div>
      </section>

      {/* Platform Details */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg p-8 shadow-lg">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Platform Features</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {platform.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Platform Stats */}
              <div className="bg-white rounded-lg p-6 shadow-lg">
                <h3 className="font-bold text-gray-900 mb-4">Platform Statistics</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Active Users</span>
                    <span className="font-medium">{platform.stats.users}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Content Library</span>
                    <span className="font-medium">{platform.stats.content}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">User Rating</span>
                    <span className="font-medium">{platform.stats.rating}</span>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="bg-white rounded-lg p-6 shadow-lg">
                <h3 className="font-bold text-gray-900 mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <a
                    href={platform.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-center font-medium transition-colors"
                  >
                    Visit Platform
                  </a>
                  <Link
                    to="/"
                    className="block w-full bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-lg text-center font-medium transition-colors"
                  >
                    Return to Hub
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PlatformPage;