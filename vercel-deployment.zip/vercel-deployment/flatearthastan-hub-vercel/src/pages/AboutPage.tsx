import React from 'react';
import { Building2, Globe, Users, Tv, Target, Award, TrendingUp, Heart, Mail, Phone, MapPin } from 'lucide-react';

const AboutPage: React.FC = () => {
  const networkStats = [
    { label: 'Connected Platforms', value: '13', icon: Globe },
    { label: 'Active Community Members', value: '15,247+', icon: Users },
    { label: 'Content Hours Produced', value: '10,000+', icon: Tv },
    { label: 'Research Papers Published', value: '89', icon: Award }
  ];

  const platforms = [
    {
      category: 'Media & Broadcasting',
      platforms: [
        { name: 'FE Channel', domain: 'FEChannel.com', description: 'Premium video streaming platform' },
        { name: 'FE Radio Live', domain: 'FERLive.com', description: 'Live radio broadcasting' },
        { name: 'FE Videos', domain: 'FEVids.com', description: 'User-generated content platform' },
        { name: 'FE Tunes', domain: 'FETunes.com', description: 'Music and podcast streaming' }
      ]
    },
    {
      category: 'Community & Social',
      platforms: [
        { name: 'FE People', domain: 'FEPeople.com', description: 'Community forums and networking' },
        { name: 'FE Memes', domain: 'FEMemes.com', description: 'Community-driven humor and content' },
        { name: 'FE Talks', domain: 'FETalks.com', description: 'Events and conference platform' }
      ]
    },
    {
      category: 'Research & Publications',
      platforms: [
        { name: 'FE Publications', domain: 'FEPub.com', description: 'Academic papers and research' },
        { name: 'FE Think Tank', domain: 'FEThink.com', description: 'Advanced research and analysis' },
        { name: 'FE News Network', domain: 'FENewsNet.com', description: 'News and investigative journalism' }
      ]
    },
    {
      category: 'Corporate & Commerce',
      platforms: [
        { name: 'FE Media Group', domain: 'FEMGp.com', description: 'Corporate headquarters' },
        { name: 'FE Merchandise', domain: 'FEMerch.com', description: 'Official branded products' },
        { name: 'Flatearthastan', domain: 'Flatearthastan.com', description: 'Central hub and portal' }
      ]
    }
  ];

  const team = [
    {
      name: 'Media Operations Team',
      role: 'Content Production & Broadcasting',
      description: 'Responsible for video production, live streaming, and multimedia content across TV and Radio platforms.'
    },
    {
      name: 'Research Council',
      role: 'Academic Research & Publications',
      description: 'Coordinates research initiatives, peer review processes, and academic publication standards.'
    },
    {
      name: 'Community Moderators',
      role: 'Community Management',
      description: 'Facilitates discussions, moderates content, and maintains positive community environment.'
    },
    {
      name: 'Technical Infrastructure',
      role: 'Platform Development',
      description: 'Maintains and develops the technical infrastructure supporting all 13 platforms.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-red-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-8">
              <div className="tv-frame p-6 bg-black">
                <img 
                  src="/images/FEChannel-TV-Flat-Earth-graphic-no-words.jpg" 
                  alt="FE Media Group" 
                  className="h-24 w-24 object-contain filter brightness-110"
                />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              About <span className="text-red-500">FE Media Group</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              The world's largest independent media ecosystem dedicated to alternative research, 
              community building, and free expression across 13 interconnected platforms.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Flat Earth Media Group exists to provide a comprehensive platform for independent research, 
                  community engagement, and alternative perspectives. We believe in the power of open dialogue, 
                  scientific inquiry, and community-driven content creation.
                </p>
                <p>
                  Our network of 13 platforms creates a unique ecosystem where researchers, content creators, 
                  and community members can collaborate, share knowledge, and explore ideas freely without 
                  censorship or external influence.
                </p>
                <p>
                  We are committed to maintaining the highest standards of content quality, community respect, 
                  and platform reliability while fostering an environment of intellectual curiosity and discovery.
                </p>
              </div>
            </div>
            <div className="lg:pl-8">
              <div className="bg-red-50 rounded-xl p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                  <Target className="h-6 w-6 text-red-500 mr-2" />
                  Core Values
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-gray-700">Independent Research & Free Inquiry</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-gray-700">Community-Driven Content Creation</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-gray-700">Open Dialogue & Respectful Discourse</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-gray-700">Platform Reliability & User Experience</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-gray-700">Transparency & Accountability</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Network Stats */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Network <span className="text-red-600">Impact</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our growing ecosystem continues to expand, connecting more people and creating more opportunities for learning and engagement.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {networkStats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
                    <div className="inline-flex p-4 bg-red-100 rounded-lg mb-4">
                      <IconComponent className="h-8 w-8 text-red-600" />
                    </div>
                    <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                    <div className="text-gray-600">{stat.label}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Platform Overview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our <span className="text-red-600">Platform Network</span>
            </h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Thirteen specialized platforms working together to create the most comprehensive independent media ecosystem available today.
            </p>
          </div>

          <div className="space-y-8">
            {platforms.map((category, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">{category.category}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {category.platforms.map((platform, platformIndex) => (
                    <div key={platformIndex} className="bg-white rounded-lg p-6 border-l-4 border-red-500">
                      <h4 className="font-bold text-gray-900 mb-1">{platform.name}</h4>
                      <p className="text-sm text-red-600 mb-2">{platform.domain}</p>
                      <p className="text-sm text-gray-600">{platform.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our <span className="text-red-600">Team</span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Dedicated professionals working to maintain and improve our platform ecosystem.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-lg">
                <h3 className="font-bold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-red-600 font-medium mb-4">{member.role}</p>
                <p className="text-gray-600 text-sm leading-relaxed">{member.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-black rounded-2xl p-8 md:p-12 text-white">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">
                  Get in <span className="text-red-500">Touch</span>
                </h2>
                <p className="text-gray-300 mb-8 leading-relaxed">
                  Whether you're interested in partnerships, have questions about our platforms, 
                  or want to contribute to our community, we'd love to hear from you.
                </p>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-red-500" />
                    <span>info@flatearthastan.com</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Building2 className="h-5 w-5 text-red-500" />
                    <span>Flat Earth Media Group Corporate</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Globe className="h-5 w-5 text-red-500" />
                    <span>Global Network • Independent Media</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-6">Quick Links</h3>
                <div className="grid grid-cols-2 gap-4">
                  <a href="https://femgp.com" className="text-gray-300 hover:text-red-400 transition-colors">Corporate Site</a>
                  <a href="https://fechannel.com" className="text-gray-300 hover:text-red-400 transition-colors">Watch FE Channel</a>
                  <a href="https://fepeople.com" className="text-gray-300 hover:text-red-400 transition-colors">Join Community</a>
                  <a href="https://fenewsnet.com" className="text-gray-300 hover:text-red-400 transition-colors">Latest News</a>
                  <a href="https://fepub.com" className="text-gray-300 hover:text-red-400 transition-colors">Research Papers</a>
                  <a href="https://femerch.com" className="text-gray-300 hover:text-red-400 transition-colors">Official Store</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;