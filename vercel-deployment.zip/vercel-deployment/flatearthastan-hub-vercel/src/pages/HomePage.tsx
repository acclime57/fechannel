import React from 'react';
import HeroSection from '../components/HeroSection';
import PlatformGrid from '../components/PlatformGrid';
import FeaturedContent from '../components/FeaturedContent';
import LiveStatus from '../components/LiveStatus';
import CommunityHighlights from '../components/CommunityHighlights';
import NewsAlerts from '../components/NewsAlerts';
import UnifiedSearch from '../components/UnifiedSearch';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <UnifiedSearch />
      <LiveStatus />
      <PlatformGrid />
      <NewsAlerts />
      <FeaturedContent />
      <CommunityHighlights />
    </div>
  );
};

export default HomePage;