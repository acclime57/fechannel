import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://pjqfangqpjldkptovoep.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBqcWZhbmdxcGpsZGtwdG92b2VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIwOTQ4MzcsImV4cCI6MjA2NzY3MDgzN30.W9nT7bE3PREO263wb0yyhCrZBH-Z4yqUR_-tmJWk1u0';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Platform {
  id: number;
  name: string;
  domain: string;
  url: string;
  description: string;
  icon_name: string;
  category: string;
  status: string;
  stats_text: string;
  color: string;
  featured: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface Content {
  id: number;
  title: string;
  description: string;
  thumbnail_url: string;
  platform_name: string;
  content_type: string;
  duration?: string;
  view_count?: string;
  like_count?: string;
  author_name: string;
  published_at: string;
  featured: boolean;
  trending: boolean;
  external_url: string;
  created_at: string;
  updated_at: string;
}

export interface News {
  id: number;
  title: string;
  description: string;
  content: string;
  source_platform: string;
  category: string;
  priority: string;
  thumbnail_url: string;
  external_url: string;
  author_name: string;
  published_at: string;
  trending: boolean;
  breaking: boolean;
  view_count: number;
  created_at: string;
  updated_at: string;
}

export interface LiveStream {
  id: number;
  title: string;
  description: string;
  platform_name: string;
  thumbnail_url: string;
  viewer_count: string;
  duration: string;
  status: string;
  stream_url: string;
  host_name: string;
  category: string;
  started_at: string;
  created_at: string;
  updated_at: string;
}

export interface Event {
  id: number;
  title: string;
  description: string;
  platform_name: string;
  event_date: string;
  event_time: string;
  timezone: string;
  participant_count: number;
  host_name: string;
  category: string;
  registration_url: string;
  thumbnail_url: string;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface CommunityPost {
  id: number;
  title: string;
  content: string;
  platform_name: string;
  author_name: string;
  reply_count: number;
  like_count: number;
  view_count: number;
  category: string;
  trending: boolean;
  featured: boolean;
  external_url: string;
  last_activity: string;
  created_at: string;
  updated_at: string;
}

export interface PlatformStat {
  id: number;
  platform_name: string;
  metric_name: string;
  metric_value: string;
  metric_change: string;
  icon_name: string;
  color: string;
  updated_at: string;
  created_at: string;
}

// API functions
export async function searchContent(query: string, platforms: string[] = []) {
  try {
    const { data, error } = await supabase.functions.invoke('unified-search', {
      body: { query, platforms }
    });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Search error:', error);
    throw error;
  }
}

export async function getDashboardData() {
  try {
    const { data, error } = await supabase.functions.invoke('content-aggregator', {
      body: { type: 'dashboard' }
    });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Dashboard data error:', error);
    throw error;
  }
}

// Direct database queries for simpler data
export async function getPlatforms() {
  const { data, error } = await supabase
    .from('platforms')
    .select('*')
    .order('sort_order', { ascending: true });

  if (error) throw error;
  return data;
}

export async function getLiveStreams() {
  const { data, error } = await supabase
    .from('live_streams')
    .select('*')
    .eq('status', 'live')
    .order('started_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function getUpcomingEvents(limit = 4) {
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('status', 'upcoming')
    .gte('event_date', new Date().toISOString())
    .order('event_date', { ascending: true })
    .limit(limit);

  if (error) throw error;
  return data;
}

export async function getFeaturedContent(limit = 6) {
  const { data, error } = await supabase
    .from('content')
    .select('*')
    .eq('featured', true)
    .order('published_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
}

export async function getRecentNews(limit = 5) {
  const { data, error } = await supabase
    .from('news')
    .select('*')
    .order('published_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
}

export async function getBreakingNews() {
  const { data, error } = await supabase
    .from('news')
    .select('*')
    .eq('breaking', true)
    .order('published_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getTrendingCommunityPosts(limit = 4) {
  const { data, error } = await supabase
    .from('community_posts')
    .select('*')
    .eq('trending', true)
    .order('last_activity', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
}

export async function getCommunityStats() {
  const { data, error } = await supabase
    .from('platform_stats')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

// Helper function to format time ago
export function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (diffInSeconds < 60) {
    return `${diffInSeconds} seconds ago`;
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60);
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else {
    const days = Math.floor(diffInSeconds / 86400);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }
}