import { useState, useEffect } from 'react';
import { 
  getDashboardData, 
  getPlatforms, 
  getLiveStreams, 
  getUpcomingEvents,
  getFeaturedContent,
  getRecentNews,
  getBreakingNews,
  getTrendingCommunityPosts,
  getCommunityStats,
  searchContent,
  Platform,
  Content,
  News,
  LiveStream,
  Event,
  CommunityPost,
  PlatformStat
} from '../lib/supabase';

interface DashboardData {
  platforms?: Platform[];
  featuredContent?: Content[];
  recentNews?: News[];
  breakingNews?: News;
  liveStreams?: LiveStream[];
  upcomingEvents?: Event[];
  trendingPosts?: CommunityPost[];
  communityStats?: PlatformStat[];
}

export function useDashboardData() {
  const [data, setData] = useState<DashboardData>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch all dashboard data in parallel
        const [platforms, featuredContent, recentNews, breakingNews, liveStreams, upcomingEvents, trendingPosts, communityStats] = await Promise.all([
          getPlatforms(),
          getFeaturedContent(),
          getRecentNews(),
          getBreakingNews(),
          getLiveStreams(),
          getUpcomingEvents(),
          getTrendingCommunityPosts(),
          getCommunityStats()
        ]);

        setData({
          platforms,
          featuredContent,
          recentNews,
          breakingNews: breakingNews || undefined,
          liveStreams,
          upcomingEvents,
          trendingPosts,
          communityStats
        });
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    }

    fetchDashboardData();
  }, []);

  const refetch = () => {
    setData({});
    setLoading(true);
    setError(null);
    // Re-run the effect
    window.location.reload();
  };

  return { data, loading, error, refetch };
}

export function useSearch() {
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = async (query: string, platforms: string[] = []) => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const response = await searchContent(query, platforms);
      setResults(response.data?.results || []);
    } catch (err) {
      console.error('Search error:', err);
      setError(err instanceof Error ? err.message : 'Search failed');
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const clearResults = () => {
    setResults([]);
    setError(null);
  };

  return { results, loading, error, search, clearResults };
}

export function usePlatforms() {
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchPlatforms() {
      try {
        setLoading(true);
        const data = await getPlatforms();
        setPlatforms(data || []);
      } catch (err) {
        console.error('Error fetching platforms:', err);
        setError(err instanceof Error ? err.message : 'Failed to load platforms');
      } finally {
        setLoading(false);
      }
    }

    fetchPlatforms();
  }, []);

  return { platforms, loading, error };
}

export function useLiveStatus() {
  const [liveStreams, setLiveStreams] = useState<LiveStream[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchLiveStatus() {
      try {
        setLoading(true);
        const [streams, events] = await Promise.all([
          getLiveStreams(),
          getUpcomingEvents()
        ]);
        setLiveStreams(streams || []);
        setUpcomingEvents(events || []);
      } catch (err) {
        console.error('Error fetching live status:', err);
        setError(err instanceof Error ? err.message : 'Failed to load live status');
      } finally {
        setLoading(false);
      }
    }

    fetchLiveStatus();
    
    // Set up real-time updates every 30 seconds
    const interval = setInterval(fetchLiveStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  return { liveStreams, upcomingEvents, loading, error };
}