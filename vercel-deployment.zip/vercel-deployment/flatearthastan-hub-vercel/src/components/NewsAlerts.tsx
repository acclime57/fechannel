import React, { useState, useEffect } from 'react';
import { AlertTriangle, Clock, TrendingUp, ExternalLink, Bell, X, Loader2 } from 'lucide-react';
import { getBreakingNews, getRecentNews, formatTimeAgo } from '../lib/supabase';
import type { News } from '../lib/supabase';

const NewsAlerts: React.FC = () => {
  const [showAlert, setShowAlert] = useState(true);
  const [breakingNews, setBreakingNews] = useState<News | null>(null);
  const [recentNews, setRecentNews] = useState<News[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchNews() {
      try {
        setLoading(true);
        const [breaking, recent] = await Promise.all([
          getBreakingNews(),
          getRecentNews(4)
        ]);
        setBreakingNews(breaking);
        setRecentNews(recent || []);
      } catch (err) {
        console.error('Error fetching news:', err);
        setError(err instanceof Error ? err.message : 'Failed to load news');
      } finally {
        setLoading(false);
      }
    }

    fetchNews();
  }, []);

  if (loading) {
    return (
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-red-500" />
            <h2 className="text-2xl font-bold text-gray-900">Loading Latest News...</h2>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600 mb-4">Error Loading News</h2>
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
      </section>
    );
  }

  // Fallback data
  const fallbackRecentNews = [
    {
      id: 2,
      title: 'Community Reaches 16,000 Members Milestone',
      description: 'FE People community celebrates unprecedented growth with new interactive features',
      published_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      source_platform: 'FE People',
      category: 'Community',
      trending: true,
      external_url: 'https://fepeople.com'
    },
    {
      id: 3,
      title: 'New Documentary Series Launches on FE Channel',
      description: 'Five-part series exploring historical perspectives and modern research methodologies',
      published_at: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      source_platform: 'FE Channel',
      category: 'Media',
      trending: false,
      external_url: 'https://fechannel.com'
    },
    {
      id: 4,
      title: 'Think Tank Publishes Peer Review Guidelines',
      description: 'New standards for academic review process now available for research submissions',
      published_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
      source_platform: 'FE Think Tank',
      category: 'Research',
      trending: false,
      external_url: 'https://fethink.com'
    }
  ];

  // Use real data if available, otherwise fallback
  const newsToShow = recentNews.length > 0 ? recentNews : fallbackRecentNews;

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Community': return 'bg-blue-100 text-blue-700';
      case 'Media': return 'bg-purple-100 text-purple-700';
      case 'Research': return 'bg-green-100 text-green-700';
      case 'Commerce': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
            <Bell className="inline h-6 w-6 text-red-500 mr-2" />
            Latest News & Updates
          </h2>
          <p className="text-gray-600">Stay informed with real-time updates from across the network</p>
        </div>

        {/* Breaking News Alert */}
        {showAlert && breakingNews && (
          <div className="mb-8">
            <div className="bg-red-50 border-l-4 border-red-500 rounded-lg p-4 relative">
              <button
                onClick={() => setShowAlert(false)}
                className="absolute top-2 right-2 text-red-400 hover:text-red-600 transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-6 w-6 text-red-500 animate-pulse" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                      BREAKING
                    </span>
                    <span className="text-sm text-red-600 font-medium">{breakingNews.source_platform}</span>
                    <span className="text-xs text-gray-500">{formatTimeAgo(breakingNews.published_at)}</span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-1">{breakingNews.title}</h3>
                  <p className="text-gray-700 mb-3">{breakingNews.description}</p>
                  <a
                    href={breakingNews.external_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-1 text-red-600 hover:text-red-800 font-medium text-sm transition-colors"
                  >
                    <span>Read Full Story</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Recent News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {newsToShow.map((news) => (
            <article key={news.id} className="content-card rounded-lg p-6 hover:scale-[1.02] transition-transform">
              {/* Article Header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium text-red-600">{news.source_platform}</span>
                  {news.trending && (
                    <div className="flex items-center space-x-1 text-orange-600">
                      <TrendingUp className="h-3 w-3" />
                      <span className="text-xs font-medium">Trending</span>
                    </div>
                  )}
                </div>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${getCategoryColor(news.category)}`}>
                  {news.category}
                </span>
              </div>

              {/* Article Content */}
              <h3 className="text-lg font-bold text-gray-900 mb-2 leading-tight">{news.title}</h3>
              <p className="text-gray-600 text-sm mb-4 leading-relaxed">{news.description}</p>

              {/* Article Footer */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1 text-xs text-gray-500">
                  <Clock className="h-3 w-3" />
                  <span>{formatTimeAgo(news.published_at)}</span>
                </div>
                <a
                  href={news.external_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-1 text-red-600 hover:text-red-800 font-medium text-sm transition-colors"
                >
                  <span>Read More</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </article>
          ))}
        </div>

        {/* News Subscription CTA */}
        <div className="mt-12 text-center">
          <div className="bg-gray-50 rounded-xl p-8 max-w-2xl mx-auto">
            <Bell className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Never Miss Important Updates
            </h3>
            <p className="text-gray-600 mb-6">
              Get real-time notifications for breaking news, research publications, and community announcements across all platforms.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://fenewsnet.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                Subscribe to News
              </a>
              <a
                href="https://fepeople.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gray-800 hover:bg-gray-900 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                Join Community Alerts
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsAlerts;