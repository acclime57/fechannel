import React from 'react';
import { Globe, Tv, Users, Radio, Newspaper, Video, Music, Image, BookOpen, MessageSquare, Brain, ShoppingBag, Play } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-black via-gray-900 to-red-900">
      {/* Background Pattern */}
      <div className="absolute inset-0 hero-pattern opacity-30"></div>
      
      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          {/* Main Logo */}
          <div className="flex justify-center mb-8">
            <div className="tv-frame p-6 bg-black">
              <img 
                src="/images/FEChannel-TV-Flat-Earth-graphic-no-words.jpg" 
                alt="Flat Earth Media Group" 
                className="h-32 w-32 object-contain filter brightness-110"
              />
            </div>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
            <span className="text-white">Welcome to </span>
            <span className="text-red-500 glow-text">Flatearthastan</span>
          </h1>
          
          <h2 className="text-xl md:text-2xl text-gray-300 mb-4 font-medium">
            Nation of Flat Earth
          </h2>
          
          <p className="text-lg md:text-xl text-gray-400 mb-12 max-w-3xl mx-auto leading-relaxed">
            Your gateway to the comprehensive <strong className="text-red-400">Flat Earth Media Ecosystem</strong>. 
            Connect with 13 powerful platforms dedicated to truth, community, and independent media.
          </p>

          {/* Platform Count Badge */}
          <div className="inline-flex items-center space-x-4 bg-black border-2 border-red-500 rounded-full px-8 py-4 mb-12">
            <Globe className="h-8 w-8 text-red-500" />
            <div className="text-left">
              <div className="text-2xl font-bold text-white">13</div>
              <div className="text-sm text-gray-400">Connected Platforms</div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="https://fechannel.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <Tv className="h-6 w-6" />
              <span>Watch FE Channel</span>
            </a>
            
            <a 
              href="https://ferlive.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-gray-800 hover:bg-gray-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all duration-300 transform hover:scale-105 border-2 border-red-500"
            >
              <Radio className="h-6 w-6" />
              <span>Listen Live</span>
            </a>
            
            <a 
              href="https://fepeople.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-transparent hover:bg-red-600 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all duration-300 border-2 border-white hover:border-red-500"
            >
              <Users className="h-6 w-6" />
              <span>Join Community</span>
            </a>
          </div>
        </div>
      </div>
      
      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
};

export default HeroSection;