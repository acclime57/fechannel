import React, { useState } from 'react';
import { Search, Filter, Globe, Loader2 } from 'lucide-react';
import { useSearch } from '../hooks/useSupabaseData';

const UnifiedSearch: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const { results, loading, error, search, clearResults } = useSearch();

  const platforms = [
    'All Platforms', 'TV Channel', 'Radio Live', 'Community', 'News Network', 
    'Videos', 'Music & Podcasts', 'Memes', 'Publications', 'Talks & Events', 
    'Think Tank', 'Merchandise'
  ];

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    await search(searchQuery, selectedPlatforms);
    setShowResults(true);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setSelectedPlatforms([]);
    setShowResults(false);
    clearResults();
  };

  return (
    <section className="bg-gray-50 border-b-2 border-red-200 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            <Globe className="inline h-6 w-6 text-red-500 mr-2" />
            Search Across All Platforms
          </h2>
          <p className="text-gray-600">Find content from the entire Flat Earth Media Ecosystem</p>
        </div>

        <form onSubmit={handleSearch} className="space-y-4">
          {/* Main Search Bar */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (e.target.value === '') {
                  handleClearSearch();
                }
              }}
              className="block w-full pl-10 pr-12 py-4 border-2 border-gray-300 rounded-lg focus:ring-red-500 focus:border-red-500 text-lg"
              placeholder="Search videos, articles, discussions, music, and more..."
            />
            <div className="absolute inset-y-0 right-0 flex items-center">
              <button
                type="button"
                onClick={() => setShowFilters(!showFilters)}
                className="mr-2 p-2 text-gray-400 hover:text-red-500 transition-colors"
              >
                <Filter className="h-5 w-5" />
              </button>
              <button
                type="submit"
                disabled={loading || !searchQuery.trim()}
                className="mr-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white px-6 py-2 rounded-md font-medium transition-colors flex items-center space-x-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Searching...</span>
                  </>
                ) : (
                  <span>Search</span>
                )}
              </button>
            </div>
          </div>

          {/* Platform Filters */}
          {showFilters && (
            <div className="bg-white border-2 border-gray-200 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-3">Filter by Platform:</h3>
              <div className="flex flex-wrap gap-2">
                {platforms.map((platform) => (
                  <button
                    key={platform}
                    type="button"
                    onClick={() => {
                      if (platform === 'All Platforms') {
                        setSelectedPlatforms([]);
                      } else {
                        setSelectedPlatforms(prev => 
                          prev.includes(platform) 
                            ? prev.filter(p => p !== platform)
                            : [...prev, platform]
                        );
                      }
                    }}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                      (platform === 'All Platforms' && selectedPlatforms.length === 0) ||
                      selectedPlatforms.includes(platform)
                        ? 'bg-red-600 text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-red-100'
                    }`}
                  >
                    {platform}
                  </button>
                ))}
              </div>
            </div>
          )}
        </form>

        {/* Search Results */}
        {showResults && (
          <div className="mt-8">
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                <p className="text-red-600">Search Error: {error}</p>
              </div>
            )}
            
            {results.length > 0 ? (
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-4">
                  Search Results ({results.length} found)
                </h3>
                <div className="space-y-4">
                  {results.map((result, index) => (
                    <div key={index} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-red-600">{result.platform_name}</span>
                          <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full capitalize">
                            {result.result_type}
                          </span>
                        </div>
                        {result.published_at && (
                          <span className="text-xs text-gray-500">
                            {new Date(result.published_at).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-gray-900 mb-2 hover:text-red-600 cursor-pointer">
                        {result.title}
                      </h4>
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                        {result.description}
                      </p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-4">
                          {result.view_count && (
                            <span>{result.view_count} views</span>
                          )}
                          {result.like_count && (
                            <span>{result.like_count} likes</span>
                          )}
                          {result.author_name && (
                            <span>by {result.author_name}</span>
                          )}
                        </div>
                        {result.external_url && (
                          <a
                            href={result.external_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-red-600 hover:text-red-800 font-medium"
                          >
                            View →
                          </a>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              !loading && (
                <div className="text-center py-8">
                  <p className="text-gray-500">No results found for "{searchQuery}"</p>
                  <button
                    onClick={handleClearSearch}
                    className="mt-2 text-red-600 hover:text-red-800 font-medium"
                  >
                    Clear search
                  </button>
                </div>
              )
            )}
          </div>
        )}

        {/* Quick Search Suggestions */}
        {!showResults && (
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500 mb-2">Popular searches:</p>
            <div className="flex flex-wrap justify-center gap-2">
              {['flat earth research', 'latest news', 'community discussions', 'live streams', 'documentaries'].map((suggestion) => (
                <button
                  key={suggestion}
                  onClick={() => {
                    setSearchQuery(suggestion);
                    search(suggestion, selectedPlatforms);
                    setShowResults(true);
                  }}
                  className="text-sm text-red-600 hover:text-red-800 underline"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default UnifiedSearch;