import React from 'react';
import { Users, MessageSquare, TrendingUp, Award, Calendar, Clock, Heart, Share, BookOpen, Brain, Star } from 'lucide-react';

const CommunityHighlights: React.FC = () => {
  const communityStats = [
    {
      platform: 'FE People',
      metric: 'Active Members',
      value: '15,247',
      change: '+1,203 this month',
      icon: Users,
      color: 'blue'
    },
    {
      platform: 'FE Talks',
      metric: 'Events Hosted',
      value: '127',
      change: '+8 this month',
      icon: Calendar,
      color: 'green'
    },
    {
      platform: 'FE Think Tank',
      metric: 'Research Papers',
      value: '89',
      change: '+3 this month',
      icon: Brain,
      color: 'purple'
    },
    {
      platform: 'FE Publications',
      metric: 'Documents Shared',
      value: '1,456',
      change: '+67 this month',
      icon: BookOpen,
      color: 'orange'
    }
  ];

  const trendingDiscussions = [
    {
      id: 1,
      title: 'Water Level Experiments: Community Results',
      platform: 'FE People',
      author: 'ResearchCollaborative',
      replies: 234,
      likes: 892,
      lastActivity: '2 hours ago',
      trending: true
    },
    {
      id: 2,
      title: 'Analyzing Historical Navigation Methods',
      platform: 'FE Think Tank',
      author: 'HistoricalAnalyst',
      replies: 156,
      likes: 543,
      lastActivity: '4 hours ago',
      trending: true
    },
    {
      id: 3,
      title: 'Community Book Club: Monthly Discussion',
      platform: 'FE People',
      author: 'BookClubModerator',
      replies: 89,
      likes: 267,
      lastActivity: '6 hours ago',
      trending: false
    },
    {
      id: 4,
      title: 'Upcoming Conference Planning Committee',
      platform: 'FE Talks',
      author: 'EventPlanner',
      replies: 67,
      likes: 134,
      lastActivity: '1 day ago',
      trending: false
    }
  ];

  const featuredMembers = [
    {
      id: 1,
      name: 'Dr. Sarah Mitchell',
      title: 'Lead Researcher',
      platform: 'FE Think Tank',
      contributions: '23 papers published',
      avatar: '/images/favicon.png',
      verified: true
    },
    {
      id: 2,
      name: 'Community Moderator Alex',
      title: 'Senior Moderator',
      platform: 'FE People',
      contributions: '2,500+ posts moderated',
      avatar: '/images/logo.png',
      verified: true
    },
    {
      id: 3,
      name: 'Independent Researcher Mike',
      title: 'Field Researcher',
      platform: 'FE Publications',
      contributions: '15 field studies completed',
      avatar: '/images/favicon.png',
      verified: false
    }
  ];

  const getStatColor = (color: string) => {
    switch (color) {
      case 'blue': return 'bg-blue-100 text-blue-700';
      case 'green': return 'bg-green-100 text-green-700';
      case 'purple': return 'bg-purple-100 text-purple-700';
      case 'orange': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Community <span className="text-red-600">Highlights</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Discover the vibrant discussions, research contributions, and member achievements across our community platforms.
          </p>
        </div>

        {/* Community Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {communityStats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <div key={index} className="content-card rounded-lg p-6 text-center">
                <div className={`inline-flex p-3 rounded-lg mb-4 ${getStatColor(stat.color)}`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm font-medium text-gray-600 mb-2">{stat.metric}</div>
                <div className="text-xs text-green-600 font-medium">{stat.change}</div>
                <div className="text-xs text-gray-500 mt-1">{stat.platform}</div>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Trending Discussions */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <TrendingUp className="h-5 w-5 text-red-500 mr-2" />
              Trending Discussions
            </h3>
            <div className="space-y-4">
              {trendingDiscussions.map((discussion) => (
                <div key={discussion.id} className="content-card rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-red-600">{discussion.platform}</span>
                      {discussion.trending && (
                        <span className="bg-orange-100 text-orange-700 text-xs px-2 py-1 rounded-full font-medium flex items-center space-x-1">
                          <TrendingUp className="h-3 w-3" />
                          <span>Trending</span>
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-gray-500">{discussion.lastActivity}</span>
                  </div>
                  
                  <h4 className="font-bold text-gray-900 mb-1 hover:text-red-600 cursor-pointer transition-colors">
                    {discussion.title}
                  </h4>
                  
                  <div className="text-sm text-gray-600 mb-3">
                    by <span className="font-medium">{discussion.author}</span>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <MessageSquare className="h-3 w-3" />
                      <span>{discussion.replies} replies</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Heart className="h-3 w-3" />
                      <span>{discussion.likes} likes</span>
                    </div>
                    <button className="flex items-center space-x-1 hover:text-red-500 transition-colors">
                      <Share className="h-3 w-3" />
                      <span>Share</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 text-center">
              <a
                href="https://fepeople.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-600 hover:text-red-800 font-medium transition-colors"
              >
                View All Discussions →
              </a>
            </div>
          </div>

          {/* Featured Members & Recent Research */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <Award className="h-5 w-5 text-red-500 mr-2" />
              Featured Contributors
            </h3>
            
            <div className="space-y-4 mb-8">
              {featuredMembers.map((member) => (
                <div key={member.id} className="content-card rounded-lg p-4">
                  <div className="flex items-center space-x-3">
                    <img 
                      src={member.avatar} 
                      alt={member.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h4 className="font-bold text-gray-900">{member.name}</h4>
                        {member.verified && (
                          <Star className="h-4 w-4 text-yellow-500" />
                        )}
                      </div>
                      <div className="text-sm text-gray-600">{member.title}</div>
                      <div className="text-xs text-red-600">{member.platform}</div>
                    </div>
                  </div>
                  <div className="mt-3 text-sm text-gray-600">
                    {member.contributions}
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Links */}
            <div className="content-card rounded-lg p-6 bg-red-50 border-red-200">
              <h4 className="font-bold text-gray-900 mb-4 flex items-center">
                <Users className="h-5 w-5 text-red-500 mr-2" />
                Join Our Community
              </h4>
              <p className="text-sm text-gray-600 mb-4">
                Connect with researchers, share discoveries, and participate in meaningful discussions.
              </p>
              <div className="space-y-2">
                <a
                  href="https://fepeople.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium text-center transition-colors"
                >
                  Join FE People
                </a>
                <a
                  href="https://fetalks.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium text-center transition-colors"
                >
                  Attend Events
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CommunityHighlights;