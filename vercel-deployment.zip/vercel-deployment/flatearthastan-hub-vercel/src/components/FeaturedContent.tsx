import React, { useState } from 'react';
import { Play, Clock, Eye, ThumbsUp, BookOpen, Headphones, Video, FileText, Calendar, Users } from 'lucide-react';

interface ContentItem {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  platform: string;
  type: 'video' | 'audio' | 'article' | 'document' | 'event';
  duration?: string;
  views?: string;
  likes?: string;
  author: string;
  publishedAt: string;
  featured: boolean;
  url: string;
}

const FeaturedContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'video' | 'audio' | 'articles' | 'research'>('all');

  const contentItems: ContentItem[] = [
    {
      id: '1',
      title: 'Understanding Horizon Phenomena: A Comprehensive Analysis',
      description: 'Deep dive into observational evidence and mathematical models explaining horizon behavior patterns.',
      thumbnail: '/images/FEChannel-TV-Flat-Earth-graphic-no-words.jpg',
      platform: 'FE Channel',
      type: 'video',
      duration: '45:32',
      views: '12.4K',
      likes: '1.2K',
      author: 'Dr. Research Team',
      publishedAt: '2 days ago',
      featured: true,
      url: 'https://fechannel.com'
    },
    {
      id: '2',
      title: 'Weekly Truth Radio: Community Spotlight',
      description: 'Featuring interviews with leading community members and discussion of recent discoveries.',
      thumbnail: '/images/favicon.png',
      platform: 'FE Radio Live',
      type: 'audio',
      duration: '1:15:20',
      views: '8.7K',
      likes: '892',
      author: 'Truth Radio Team',
      publishedAt: '3 days ago',
      featured: true,
      url: 'https://ferlive.com'
    },
    {
      id: '3',
      title: 'Geodetic Surveys and Alternative Interpretations',
      description: 'Peer-reviewed analysis of historical and contemporary land surveying methodologies.',
      thumbnail: '/images/logo.png',
      platform: 'FE Publications',
      type: 'document',
      views: '3.2K',
      author: 'Research Council',
      publishedAt: '1 week ago',
      featured: true,
      url: 'https://fepub.com'
    },
    {
      id: '4',
      title: 'Community Discussion: Water Behavior Studies',
      description: 'In-depth forum discussion analyzing water level experiments and community observations.',
      thumbnail: '/images/Free-Earth-Flat-Earth-TV-channel-graphic.jpg',
      platform: 'FE People',
      type: 'article',
      views: '5.1K',
      likes: '423',
      author: 'Community Forum',
      publishedAt: '4 days ago',
      featured: false,
      url: 'https://fepeople.com'
    },
    {
      id: '5',
      title: 'Monthly Think Tank Symposium',
      description: 'Upcoming virtual conference featuring presentations from researchers worldwide.',
      thumbnail: '/images/fechannel-logo-v-720X480.jpg',
      platform: 'FE Talks',
      type: 'event',
      author: 'Event Organizers',
      publishedAt: 'Next Friday',
      featured: true,
      url: 'https://fetalks.com'
    },
    {
      id: '6',
      title: 'Independent Music: Songs of Truth',
      description: 'Original compositions inspired by independent research and community experiences.',
      thumbnail: '/images/favicon.png',
      platform: 'FE Tunes',
      type: 'audio',
      duration: '3:45',
      views: '2.8K',
      likes: '287',
      author: 'Independent Artists',
      publishedAt: '5 days ago',
      featured: false,
      url: 'https://fetunes.com'
    }
  ];

  const getFilteredContent = () => {
    if (activeTab === 'all') return contentItems;
    if (activeTab === 'video') return contentItems.filter(item => item.type === 'video');
    if (activeTab === 'audio') return contentItems.filter(item => item.type === 'audio');
    if (activeTab === 'articles') return contentItems.filter(item => item.type === 'article');
    if (activeTab === 'research') return contentItems.filter(item => item.type === 'document' || item.type === 'event');
    return contentItems;
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return <Video className="h-4 w-4" />;
      case 'audio': return <Headphones className="h-4 w-4" />;
      case 'article': return <FileText className="h-4 w-4" />;
      case 'document': return <BookOpen className="h-4 w-4" />;
      case 'event': return <Calendar className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const featuredContent = contentItems.filter(item => item.featured);
  const filteredContent = getFilteredContent();

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Featured <span className="text-red-600">Content</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Discover the best content from across our network - from in-depth research to community discussions and live events.
          </p>
        </div>

        {/* Featured Highlights */}
        <div className="mb-12">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Editor's Picks</h3>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {featuredContent.slice(0, 3).map((item) => (
              <div key={item.id} className="content-card rounded-xl overflow-hidden hover:scale-[1.02] transition-transform">
                <div className="relative">
                  <img 
                    src={item.thumbnail} 
                    alt={item.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Play className="h-12 w-12 text-white" />
                  </div>
                  <div className="absolute top-3 left-3">
                    <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                      FEATURED
                    </span>
                  </div>
                  <div className="absolute top-3 right-3">
                    <span className="bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded flex items-center space-x-1">
                      {getTypeIcon(item.type)}
                      <span className="capitalize">{item.type}</span>
                    </span>
                  </div>
                  {item.duration && (
                    <div className="absolute bottom-3 right-3">
                      <span className="bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                        {item.duration}
                      </span>
                    </div>
                  )}
                </div>
                
                <div className="p-6">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-sm font-medium text-red-600">{item.platform}</span>
                    <span className="text-xs text-gray-500">{item.publishedAt}</span>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2 line-clamp-2">{item.title}</h4>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">{item.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      {item.views && (
                        <div className="flex items-center space-x-1">
                          <Eye className="h-3 w-3" />
                          <span>{item.views}</span>
                        </div>
                      )}
                      {item.likes && (
                        <div className="flex items-center space-x-1">
                          <ThumbsUp className="h-3 w-3" />
                          <span>{item.likes}</span>
                        </div>
                      )}
                    </div>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-red-600 hover:text-red-800 font-medium text-sm transition-colors"
                    >
                      View →
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Content Tabs */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 justify-center">
            {[
              { id: 'all', label: 'All Content', icon: Users },
              { id: 'video', label: 'Videos', icon: Video },
              { id: 'audio', label: 'Audio', icon: Headphones },
              { id: 'articles', label: 'Articles', icon: FileText },
              { id: 'research', label: 'Research', icon: BookOpen }
            ].map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`inline-flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                    activeTab === tab.id
                      ? 'bg-red-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-red-50 hover:text-red-600'
                  }`}
                >
                  <IconComponent className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContent.slice(0, 6).map((item) => (
            <div key={item.id} className="content-card rounded-lg p-4 hover:scale-[1.02] transition-transform">
              <div className="flex items-start space-x-3">
                <img 
                  src={item.thumbnail} 
                  alt={item.title}
                  className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    {getTypeIcon(item.type)}
                    <span className="text-xs font-medium text-red-600">{item.platform}</span>
                  </div>
                  <h4 className="font-bold text-gray-900 text-sm mb-1 line-clamp-2">{item.title}</h4>
                  <p className="text-xs text-gray-600 mb-2 line-clamp-2">{item.description}</p>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{item.publishedAt}</span>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-red-600 hover:text-red-800 font-medium transition-colors"
                    >
                      View
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View More */}
        <div className="text-center mt-8">
          <button className="bg-gray-800 hover:bg-gray-900 text-white px-8 py-3 rounded-lg font-medium transition-colors">
            Load More Content
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedContent;