import React from 'react';
import { Radio, Tv, Calendar, Clock, Users, Volume2, Play, Pause, Loader2 } from 'lucide-react';
import { useLiveStatus } from '../hooks/useSupabaseData';
import { formatTimeAgo } from '../lib/supabase';

const LiveStatus: React.FC = () => {
  const { liveStreams, upcomingEvents, loading, error } = useLiveStatus();

  if (loading) {
    return (
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              <span className="inline-flex items-center">
                <Loader2 className="w-6 h-6 animate-spin mr-3" />
                Loading Live Status...
              </span>
            </h2>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600 mb-4">Error Loading Live Status</h2>
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
      </section>
    );
  }

  // Mock data as fallback (can be removed once backend is fully populated)
  const fallbackStreams = [
    {
      id: 1,
      platform_name: 'FE Channel',
      title: 'Daily Truth Broadcast',
      description: 'Live discussion on latest research and community updates',
      thumbnail_url: '/images/Free-Earth-Flat-Earth-TV-channel-graphic.jpg',
      viewer_count: '1,247',
      duration: '2:34:12',
      status: 'live',
      stream_url: 'https://fechannel.com'
    },
    {
      id: 2,
      platform_name: 'FE Radio Live',
      title: 'Morning Truth Radio',
      description: 'Starting your day with independent news and analysis',
      thumbnail_url: '/images/favicon.png',
      viewer_count: '892',
      duration: '1:45:30',
      status: 'live',
      stream_url: 'https://ferlive.com'
    }
  ];

  const fallbackEvents = [
    {
      id: 1,
      title: 'Community Q&A Session',
      platform_name: 'FE Talks',
      event_time: '3:00 PM EST',
      event_date: new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString(),
      participant_count: 45
    },
    {
      id: 2,
      title: 'Research Paper Discussion',
      platform_name: 'FE Think Tank',
      event_time: '7:00 PM EST',
      event_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      participant_count: 23
    }
  ];

  // Use real data if available, otherwise fallback
  const streamsToShow = liveStreams.length > 0 ? liveStreams : fallbackStreams;
  const eventsToShow = upcomingEvents.length > 0 ? upcomingEvents : fallbackEvents;

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
            <span className="inline-flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse mr-3"></div>
              Live Now & Upcoming
            </span>
          </h2>
          <p className="text-gray-600">Stay connected with live streams and scheduled events across the network</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Live Streams */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
              Currently Live
            </h3>
            <div className="space-y-4">
              {streamsToShow.map((stream) => (
                <div key={stream.id} className="content-card rounded-lg p-4 hover:scale-[1.02] transition-transform">
                  <div className="flex items-start space-x-4">
                    {/* Thumbnail */}
                    <div className="relative flex-shrink-0">
                      <img 
                        src={stream.thumbnail_url || '/images/favicon.png'} 
                        alt={stream.title}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-40 rounded-lg flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Play className="h-6 w-6 text-white" />
                      </div>
                      <div className="absolute top-1 right-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
                        LIVE
                      </div>
                    </div>

                    {/* Stream Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <Tv className="h-4 w-4 text-red-500" />
                        <span className="text-sm font-medium text-red-600">{stream.platform_name}</span>
                      </div>
                      <h4 className="font-bold text-gray-900 mb-1 truncate">{stream.title}</h4>
                      <p className="text-sm text-gray-600 mb-2 line-clamp-2">{stream.description}</p>
                      
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Users className="h-3 w-3" />
                          <span>{stream.viewer_count} viewers</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>{stream.duration}</span>
                        </div>
                      </div>
                    </div>

                    {/* Watch Button */}
                    <div className="flex-shrink-0">
                      <a
                        href={stream.stream_url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1"
                      >
                        <Volume2 className="h-3 w-3" />
                        <span>Watch</span>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* View All Live */}
            <div className="mt-4 text-center">
              <button className="text-red-600 hover:text-red-800 font-medium text-sm transition-colors">
                View All Live Streams →
              </button>
            </div>
          </div>

          {/* Upcoming Events */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <Calendar className="h-5 w-5 text-gray-600 mr-2" />
              Upcoming Events
            </h3>
            <div className="space-y-4">
              {eventsToShow.map((event) => (
                <div key={event.id} className="content-card rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-red-600">{event.platform_name}</span>
                    <span className="text-xs text-gray-500">
                      {new Date(event.event_date).toLocaleDateString() === new Date().toLocaleDateString() 
                        ? 'Today' 
                        : new Date(event.event_date).toLocaleDateString()}
                    </span>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-1">{event.title}</h4>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <Clock className="h-3 w-3" />
                      <span>{event.event_time || formatTimeAgo(event.event_date)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-3 w-3" />
                      <span>{event.participant_count} interested</span>
                    </div>
                  </div>
                </div>
              ))}

              {/* Event Calendar Link */}
              <div className="content-card rounded-lg p-4 bg-red-50 border-red-200">
                <div className="text-center">
                  <Calendar className="h-8 w-8 text-red-500 mx-auto mb-2" />
                  <h4 className="font-bold text-gray-900 mb-1">Full Event Calendar</h4>
                  <p className="text-sm text-gray-600 mb-3">View all upcoming talks, conferences, and community events</p>
                  <a
                    href="https://fetalks.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                  >
                    View Calendar
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LiveStatus;