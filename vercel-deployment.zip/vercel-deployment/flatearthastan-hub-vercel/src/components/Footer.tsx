import React from 'react';
import { Link } from 'react-router-dom';
import { Globe, Mail, Phone, MapPin, Facebook, Twitter, Youtube, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const platformCategories = [
    {
      title: 'Media Platforms',
      platforms: [
        { name: 'FE Channel (TV)', url: 'https://fechannel.com' },
        { name: 'FE Radio Live', url: 'https://ferlive.com' },
        { name: 'FE Videos', url: 'https://fevids.com' },
        { name: 'FE Tunes (Music)', url: 'https://fetunes.com' }
      ]
    },
    {
      title: 'Community & Content',
      platforms: [
        { name: 'FE People', url: 'https://fepeople.com' },
        { name: 'FE News Network', url: 'https://fenewsnet.com' },
        { name: 'FE Memes', url: 'https://fememes.com' },
        { name: 'FE Talks & Events', url: 'https://fetalks.com' }
      ]
    },
    {
      title: 'Research & Commerce',
      platforms: [
        { name: 'FE Publications', url: 'https://fepub.com' },
        { name: 'FE Think Tank', url: 'https://fethink.com' },
        { name: 'FE Merchandise', url: 'https://femerch.com' },
        { name: 'FE Media Group', url: 'https://femgp.com' }
      ]
    }
  ];

  return (
    <footer className="bg-black border-t-4 border-red-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="tv-frame p-2">
                <img 
                  src="/images/favicon.png" 
                  alt="FE Media Group" 
                  className="h-8 w-8 filter brightness-110"
                />
              </div>
              <div>
                <h3 className="text-xl font-bold text-red-500">Flatearthastan</h3>
                <p className="text-gray-400 text-sm">Nation of Flat Earth</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4 text-sm leading-relaxed">
              The comprehensive hub for the Flat Earth Media Ecosystem, connecting 13 platforms dedicated to truth, community, and independent media.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Platform Categories */}
          {platformCategories.map((category, index) => (
            <div key={index}>
              <h4 className="text-white font-bold mb-4">{category.title}</h4>
              <ul className="space-y-2">
                {category.platforms.map((platform, platformIndex) => (
                  <li key={platformIndex}>
                    <a
                      href={platform.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-red-400 transition-colors text-sm"
                    >
                      {platform.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Contact & Legal Section */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Contact Information */}
            <div>
              <h4 className="text-white font-bold mb-4">Contact Information</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2 text-gray-400">
                  <Mail className="h-4 w-4" />
                  <span>info@flatearthastan.com</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-400">
                  <Globe className="h-4 w-4" />
                  <span>Flat Earth Media Group Corporate</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-400">
                  <MapPin className="h-4 w-4" />
                  <span>Global Network • Independent Media</span>
                </div>
              </div>
            </div>

            {/* Legal Links */}
            <div>
              <h4 className="text-white font-bold mb-4">Legal & Policies</h4>
              <div className="space-y-2 text-sm">
                <Link to="#" className="block text-gray-400 hover:text-red-400 transition-colors">
                  Privacy Policy
                </Link>
                <Link to="#" className="block text-gray-400 hover:text-red-400 transition-colors">
                  Terms of Service
                </Link>
                <Link to="#" className="block text-gray-400 hover:text-red-400 transition-colors">
                  Community Guidelines
                </Link>
                <Link to="/about" className="block text-gray-400 hover:text-red-400 transition-colors">
                  About FEMG
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 mt-8 pt-6 text-center">
          <p className="text-gray-400 text-sm">
            © {currentYear} Flat Earth Media Group. All rights reserved. | 
            <span className="text-red-400"> Flatearthastan.com</span> - Nation of Flat Earth
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;