import React from 'react';
import { Tv, Radio, Users, Newspaper, Video, Music, Image, BookOpen, MessageSquare, Brain, ShoppingBag, Building2, ExternalLink, Play, Headphones, FileText, Calendar, Users2, ShoppingCart } from 'lucide-react';
import { usePlatforms } from '../hooks/useSupabaseData';
import { Platform } from '../lib/supabase';

const PlatformGrid: React.FC = () => {
  const { platforms, loading, error } = usePlatforms();

  // Icon mapping
  const iconMap: { [key: string]: React.ComponentType<any> } = {
    Building2,
    Tv,
    Radio,
    Users,
    Newspaper,
    Video,
    Music,
    Image,
    BookOpen,
    MessageSquare,
    Brain,
    ShoppingBag
  };

  if (loading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Explore All <span className="text-red-600">13 Platforms</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Loading platform information...
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(13)].map((_, i) => (
              <div key={i} className="bg-gray-200 animate-pulse rounded-xl h-48"></div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-red-600 mb-4">Error Loading Platforms</h2>
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
      </section>
    );
  }

  const platformsData: (Platform & { iconComponent?: React.ComponentType<any> })[] = platforms.map(platform => (
    {
      ...platform,
      iconComponent: iconMap[platform.icon_name] || Building2
    }
  ));

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-red-500';
      case 'active': return 'bg-green-500';
      case 'updated': return 'bg-orange-500';
      case 'new': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'live': return 'LIVE';
      case 'active': return 'ACTIVE';
      case 'updated': return 'UPDATED';
      case 'new': return 'NEW';
      default: return 'STATUS';
    }
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Explore All <span className="text-red-600">13 Platforms</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Discover the complete Flat Earth Media Ecosystem. Each platform offers unique content 
            and community features designed to connect, inform, and engage our global audience.
          </p>
        </div>

        {/* Platform Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {platformsData.map((platform) => {
            const IconComponent = platform.iconComponent || Building2;
            const isMainHub = platform.domain === 'Flatearthastan.com';
            
            return (
              <div
                key={platform.id}
                className={`platform-card rounded-xl p-6 relative overflow-hidden group ${
                  isMainHub ? 'ring-4 ring-red-500 bg-red-50' : ''
                }`}
              >
                {/* Status Badge */}
                <div className="absolute top-4 right-4">
                  <div className={`${getStatusColor(platform.status)} text-white text-xs font-bold px-2 py-1 rounded-full`}>
                    {getStatusText(platform.status)}
                  </div>
                </div>

                {/* Platform Icon */}
                <div className={`mb-4 p-3 rounded-lg inline-block ${
                  isMainHub ? 'bg-red-100' : 'bg-gray-100 group-hover:bg-red-100'
                } transition-colors`}>
                  <IconComponent className={`h-8 w-8 ${
                    isMainHub ? 'text-red-600' : 'text-gray-700 group-hover:text-red-600'
                  } transition-colors`} />
                </div>

                {/* Platform Info */}
                <h3 className="text-lg font-bold text-gray-900 mb-1">{platform.name}</h3>
                <p className="text-sm text-red-600 font-medium mb-2">{platform.domain}</p>
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">{platform.description}</p>

                {/* Stats */}
                {platform.stats_text && (
                  <div className="text-xs text-gray-500 mb-4 font-medium">
                    {platform.stats_text}
                  </div>
                )}

                {/* Action Button */}
                <div className="flex items-center justify-between">
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    platform.category === 'Media' ? 'bg-red-100 text-red-700' :
                    platform.category === 'Community' ? 'bg-blue-100 text-blue-700' :
                    platform.category === 'Research' ? 'bg-purple-100 text-purple-700' :
                    platform.category === 'Commerce' ? 'bg-green-100 text-green-700' :
                    platform.category === 'Events' ? 'bg-orange-100 text-orange-700' :
                    platform.category === 'News' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {platform.category}
                  </span>
                  
                  {!isMainHub && (
                    <a
                      href={platform.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-1 text-red-600 hover:text-red-800 font-medium text-sm transition-colors"
                    >
                      <span>Visit</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                  
                  {isMainHub && (
                    <span className="text-red-600 font-medium text-sm">
                      Current Hub
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <div className="bg-gray-50 rounded-xl p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Ready to explore the entire ecosystem?
            </h3>
            <p className="text-gray-600 mb-6">
              Start with our most popular platforms or dive deep into research and community discussions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://fechannel.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                <Play className="h-4 w-4" />
                <span>Start Watching</span>
              </a>
              <a
                href="https://fepeople.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 bg-gray-800 hover:bg-gray-900 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                <Users2 className="h-4 w-4" />
                <span>Join Community</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PlatformGrid;