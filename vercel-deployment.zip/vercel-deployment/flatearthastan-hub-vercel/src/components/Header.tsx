import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Globe, Tv, Radio, Users, Newspaper, Video, Music, Image, BookOpen, MessageSquare, Brain, ShoppingBag } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const platforms = [
    { name: 'TV Channel', url: 'https://fechannel.com', icon: Tv, description: 'Video Streaming' },
    { name: 'Radio Live', url: 'https://ferlive.com', icon: Radio, description: 'Audio Streaming' },
    { name: 'Community', url: 'https://fepeople.com', icon: Users, description: 'People & Forums' },
    { name: 'News Network', url: 'https://fenewsnet.com', icon: Newspaper, description: 'Breaking News' },
    { name: 'Videos', url: 'https://fevids.com', icon: Video, description: 'User Content' },
    { name: 'Music & Podcasts', url: 'https://fetunes.com', icon: Music, description: 'Audio Content' },
    { name: 'Memes', url: 'https://fememes.com', icon: Image, description: 'Community Memes' },
    { name: 'Publications', url: 'https://fepub.com', icon: BookOpen, description: 'Research & Docs' },
    { name: 'Talks & Events', url: 'https://fetalks.com', icon: MessageSquare, description: 'Conferences' },
    { name: 'Think Tank', url: 'https://fethink.com', icon: Brain, description: 'Research & Analysis' },
    { name: 'Merchandise', url: 'https://femerch.com', icon: ShoppingBag, description: 'Official Store' }
  ];

  return (
    <header className="bg-black border-b-4 border-red-500 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Brand */}
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="tv-frame p-2 group-hover:scale-105 transition-transform duration-300">
              <img 
                src="/images/favicon.png" 
                alt="FE Media Group" 
                className="h-8 w-8 filter brightness-110"
              />
            </div>
            <div className="text-white">
              <h1 className="text-xl font-bold text-red-500">Flatearthastan</h1>
              <p className="text-xs text-gray-300 -mt-1">Nation of Flat Earth</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <Link to="/" className="text-white hover:text-red-400 font-medium transition-colors">
              Home
            </Link>
            <Link to="/about" className="text-white hover:text-red-400 font-medium transition-colors">
              About FEMG
            </Link>
            
            {/* Platforms Dropdown */}
            <div className="relative group">
              <button className="text-white hover:text-red-400 font-medium transition-colors flex items-center space-x-1">
                <Globe className="h-4 w-4" />
                <span>All Platforms</span>
              </button>
              <div className="absolute top-full left-0 mt-2 w-80 bg-black border border-red-500 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                <div className="p-4">
                  <h3 className="text-red-500 font-bold mb-3">Flat Earth Media Network</h3>
                  <div className="space-y-2">
                    {platforms.map((platform, index) => {
                      const IconComponent = platform.icon;
                      return (
                        <a
                          key={index}
                          href={platform.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center space-x-3 p-2 rounded hover:bg-gray-800 transition-colors group/item"
                        >
                          <IconComponent className="h-4 w-4 text-red-400 group-hover/item:text-red-300" />
                          <div>
                            <div className="text-white text-sm font-medium">{platform.name}</div>
                            <div className="text-gray-400 text-xs">{platform.description}</div>
                          </div>
                        </a>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            <a 
              href="https://femerch.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Shop Now
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden text-white hover:text-red-400 transition-colors"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden bg-gray-900 border-t border-gray-700">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link
                to="/"
                className="block px-3 py-2 text-white hover:text-red-400 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                to="/about"
                className="block px-3 py-2 text-white hover:text-red-400 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                About FEMG
              </Link>
              
              <div className="border-t border-gray-700 pt-3 mt-3">
                <h3 className="px-3 text-red-500 font-bold mb-2">All Platforms</h3>
                {platforms.map((platform, index) => {
                  const IconComponent = platform.icon;
                  return (
                    <a
                      key={index}
                      href={platform.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-3 px-3 py-2 text-white hover:text-red-400 transition-colors"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <IconComponent className="h-4 w-4" />
                      <span className="text-sm">{platform.name}</span>
                    </a>
                  );
                })}
              </div>
              
              <div className="border-t border-gray-700 pt-3 mt-3">
                <a 
                  href="https://femerch.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mx-3 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-medium text-center transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Shop Now
                </a>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;