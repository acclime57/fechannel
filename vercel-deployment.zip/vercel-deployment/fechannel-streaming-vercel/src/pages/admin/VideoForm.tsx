import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, X, Video, Image as ImageIcon, Plus, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface Video {
  id: string;
  title: string;
  description: string;
  video_url: string;
  thumbnail_url: string;
  category_id: string;
  tags: string[];
  duration: number;
  featured: boolean;
  view_count: number;
  file_size_mb?: number;
  created_at: string;
}

interface UploadProgress {
  video?: number;
  thumbnail?: number;
  status: 'idle' | 'uploading' | 'processing' | 'complete' | 'error';
  message?: string;
}

interface VideoFormProps {
  video?: Video | null;
  onSubmit: (videoData: Partial<Video>, videoFile?: File, thumbnailFile?: File) => Promise<void>;
  onCancel: () => void;
  uploadProgress: UploadProgress;
}

const CATEGORIES = [
  { value: 'documentaries', label: 'Documentaries' },
  { value: 'interviews', label: 'Interviews' },
  { value: 'educational', label: 'Educational' },
  { value: 'featured', label: 'Featured' },
  { value: 'series', label: 'Series' },
  { value: 'live', label: 'Live Streams' }
];

const POPULAR_TAGS = [
  'flat earth', 'documentary', 'research', 'science', 'theory',
  'evidence', 'investigation', 'nasa', 'space', 'history',
  'antarctica', 'gravity', 'astronomy', 'physics', 'truth'
];

export const VideoForm: React.FC<VideoFormProps> = ({
  video,
  onSubmit,
  onCancel,
  uploadProgress
}) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category_id: 'featured',
    tags: [] as string[],
    featured: false,
    duration: 0,
    view_count: 0,
    video_url: '',
    thumbnail_url: ''
  });

  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [newTag, setNewTag] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (video) {
      setFormData({
        title: video.title,
        description: video.description,
        category_id: video.category_id,
        tags: video.tags,
        featured: video.featured,
        duration: video.duration,
        view_count: video.view_count,
        video_url: video.video_url,
        thumbnail_url: video.thumbnail_url
      });
    }
  }, [video]);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFileUpload = (file: File, type: 'video' | 'thumbnail') => {
    if (type === 'video') {
      if (file.type.startsWith('video/')) {
        setVideoFile(file);
        // Auto-estimate duration based on file size (rough estimate)
        const estimatedDuration = Math.round(file.size / (1024 * 1024) * 45);
        handleInputChange('duration', estimatedDuration);
      } else {
        setErrors(prev => ({ ...prev, video: 'Please select a valid video file' }));
      }
    } else {
      if (file.type.startsWith('image/')) {
        setThumbnailFile(file);
      } else {
        setErrors(prev => ({ ...prev, thumbnail: 'Please select a valid image file' }));
      }
    }
  };

  const handleDrop = (e: React.DragEvent, type: 'video' | 'thumbnail') => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0], type);
    }
  };

  const addTag = () => {
    if (newTag && !formData.tags.includes(newTag)) {
      handleInputChange('tags', [...formData.tags, newTag]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    handleInputChange('tags', formData.tags.filter(tag => tag !== tagToRemove));
  };

  const addPopularTag = (tag: string) => {
    if (!formData.tags.includes(tag)) {
      handleInputChange('tags', [...formData.tags, tag]);
    }
  };

  const generateSEOTitle = () => {
    const keywords = formData.tags.slice(0, 3).join(' ');
    return `${formData.title} | ${keywords} | FEChannel`;
  };

  const generateSEODescription = () => {
    return `${formData.description.slice(0, 120)}... Watch on FEChannel - The Flat Earth TV Channel.`;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (!video && !videoFile && !formData.video_url) {
      newErrors.video = 'Video file or URL is required';
    }

    if (formData.tags.length === 0) {
      newErrors.tags = 'At least one tag is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    try {
      await onSubmit(formData, videoFile || undefined, thumbnailFile || undefined);
    } catch (error) {
      console.error('Submit error:', error);
    }
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    if (mb < 1000) return `${mb.toFixed(1)} MB`;
    return `${(mb / 1000).toFixed(1)} GB`;
  };

  const isUploading = uploadProgress.status === 'uploading' || uploadProgress.status === 'processing';

  return (
    <div className=\"fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4\">
      <Card className=\"w-full max-w-4xl max-h-[90vh] overflow-y-auto\">
        <CardHeader>
          <div className=\"flex items-center justify-between\">
            <div>
              <CardTitle>{video ? 'Edit Video' : 'Add New Video'}</CardTitle>
              <CardDescription>
                Upload and manage your video content with SEO optimization
              </CardDescription>
            </div>
            <Button variant=\"ghost\" size=\"sm\" onClick={onCancel} disabled={isUploading}>
              <X className=\"h-4 w-4\" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className=\"space-y-6\">
          {/* Upload Progress */}
          {uploadProgress.status !== 'idle' && (
            <Alert className={uploadProgress.status === 'error' ? 'border-red-200 bg-red-50' : 'border-blue-200 bg-blue-50'}>
              <div className=\"flex items-center\">
                {uploadProgress.status === 'error' ? (
                  <AlertCircle className=\"h-4 w-4 text-red-600\" />
                ) : uploadProgress.status === 'complete' ? (
                  <CheckCircle className=\"h-4 w-4 text-green-600\" />
                ) : (
                  <Loader2 className=\"h-4 w-4 animate-spin text-blue-600\" />
                )}
                <AlertDescription className=\"ml-2\">{uploadProgress.message}</AlertDescription>
              </div>
              {(uploadProgress.video !== undefined || uploadProgress.thumbnail !== undefined) && (
                <div className=\"mt-2 space-y-1\">
                  {uploadProgress.video !== undefined && (
                    <div className=\"flex items-center text-sm\">
                      <span className=\"w-16\">Video:</span>
                      <div className=\"flex-1 bg-gray-200 rounded-full h-2 mx-2\">
                        <div 
                          className=\"bg-blue-600 h-2 rounded-full transition-all duration-300\" 
                          style={{ width: `${uploadProgress.video}%` }}
                        />
                      </div>
                      <span>{uploadProgress.video}%</span>
                    </div>
                  )}
                  {uploadProgress.thumbnail !== undefined && (
                    <div className=\"flex items-center text-sm\">
                      <span className=\"w-16\">Thumbnail:</span>
                      <div className=\"flex-1 bg-gray-200 rounded-full h-2 mx-2\">
                        <div 
                          className=\"bg-blue-600 h-2 rounded-full transition-all duration-300\" 
                          style={{ width: `${uploadProgress.thumbnail}%` }}
                        />
                      </div>
                      <span>{uploadProgress.thumbnail}%</span>
                    </div>
                  )}
                </div>
              )}
            </Alert>
          )}

          <form onSubmit={handleSubmit} className=\"space-y-6\">
            {/* Basic Information */}
            <div className=\"grid gap-4 md:grid-cols-2\">
              <div className=\"space-y-2\">
                <Label htmlFor=\"title\">Video Title *</Label>
                <Input
                  id=\"title\"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  placeholder=\"Enter video title\"
                  disabled={isUploading}
                />
                {errors.title && <p className=\"text-sm text-red-600\">{errors.title}</p>}
              </div>

              <div className=\"space-y-2\">
                <Label htmlFor=\"category\">Category *</Label>
                <Select
                  value={formData.category_id}
                  onValueChange={(value) => handleInputChange('category_id', value)}
                  disabled={isUploading}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Description */}
            <div className=\"space-y-2\">
              <Label htmlFor=\"description\">Description *</Label>
              <Textarea
                id=\"description\"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder=\"Describe your video content...\"
                rows={4}
                disabled={isUploading}
              />
              {errors.description && <p className=\"text-sm text-red-600\">{errors.description}</p>}
              <p className=\"text-sm text-slate-500\">
                SEO Description: {generateSEODescription()}
              </p>
            </div>

            {/* Video Upload */}
            <div className=\"space-y-4\">
              <Label>Video File {!video && '*'}</Label>
              
              {!video && (
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${\n                    dragOver\n                      ? 'border-blue-400 bg-blue-50'\n                      : errors.video\n                      ? 'border-red-300 bg-red-50'\n                      : 'border-gray-300 hover:border-gray-400'\n                  }`}\n                  onDrop={(e) => handleDrop(e, 'video')}\n                  onDragOver={(e) => {\n                    e.preventDefault();\n                    setDragOver(true);\n                  }}\n                  onDragLeave={() => setDragOver(false)}\n                >\n                  {videoFile ? (\n                    <div className=\"space-y-2\">\n                      <Video className=\"h-12 w-12 mx-auto text-green-600\" />\n                      <p className=\"font-medium\">{videoFile.name}</p>\n                      <p className=\"text-sm text-slate-600\">{formatFileSize(videoFile.size)}</p>\n                      <Button\n                        type=\"button\"\n                        variant=\"outline\"\n                        size=\"sm\"\n                        onClick={() => setVideoFile(null)}\n                        disabled={isUploading}\n                      >\n                        Remove\n                      </Button>\n                    </div>\n                  ) : (\n                    <div className=\"space-y-2\">\n                      <Upload className=\"h-12 w-12 mx-auto text-slate-400\" />\n                      <div>\n                        <p className=\"font-medium\">Drop your video file here</p>\n                        <p className=\"text-sm text-slate-600\">or click to browse</p>\n                      </div>\n                      <Input\n                        type=\"file\"\n                        accept=\"video/*\"\n                        onChange={(e) => {\n                          const file = e.target.files?.[0];\n                          if (file) handleFileUpload(file, 'video');\n                        }}\n                        className=\"hidden\"\n                        id=\"video-upload\"\n                        disabled={isUploading}\n                      />\n                      <Label\n                        htmlFor=\"video-upload\"\n                        className=\"cursor-pointer inline-block px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50\"\n                      >\n                        Choose Video File\n                      </Label>\n                    </div>\n                  )}\n                </div>\n              )}\n              \n              {errors.video && <p className=\"text-sm text-red-600\">{errors.video}</p>}\n            </div>\n\n            {/* Thumbnail Upload */}\n            <div className=\"space-y-4\">\n              <Label>Thumbnail Image</Label>\n              \n              <div className=\"grid gap-4 md:grid-cols-2\">\n                <div\n                  className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${\n                    dragOver\n                      ? 'border-blue-400 bg-blue-50'\n                      : 'border-gray-300 hover:border-gray-400'\n                  }`}\n                  onDrop={(e) => handleDrop(e, 'thumbnail')}\n                  onDragOver={(e) => {\n                    e.preventDefault();\n                    setDragOver(true);\n                  }}\n                  onDragLeave={() => setDragOver(false)}\n                >\n                  {thumbnailFile ? (\n                    <div className=\"space-y-2\">\n                      <img\n                        src={URL.createObjectURL(thumbnailFile)}\n                        alt=\"Thumbnail preview\"\n                        className=\"h-20 w-32 mx-auto rounded object-cover\"\n                      />\n                      <p className=\"font-medium text-sm\">{thumbnailFile.name}</p>\n                      <Button\n                        type=\"button\"\n                        variant=\"outline\"\n                        size=\"sm\"\n                        onClick={() => setThumbnailFile(null)}\n                        disabled={isUploading}\n                      >\n                        Remove\n                      </Button>\n                    </div>\n                  ) : (\n                    <div className=\"space-y-2\">\n                      <ImageIcon className=\"h-8 w-8 mx-auto text-slate-400\" />\n                      <p className=\"text-sm\">Drop thumbnail here</p>\n                      <Input\n                        type=\"file\"\n                        accept=\"image/*\"\n                        onChange={(e) => {\n                          const file = e.target.files?.[0];\n                          if (file) handleFileUpload(file, 'thumbnail');\n                        }}\n                        className=\"hidden\"\n                        id=\"thumbnail-upload\"\n                        disabled={isUploading}\n                      />\n                      <Label\n                        htmlFor=\"thumbnail-upload\"\n                        className=\"cursor-pointer inline-block px-3 py-1 text-sm bg-white border border-gray-300 rounded hover:bg-gray-50\"\n                      >\n                        Choose Image\n                      </Label>\n                    </div>\n                  )}\n                </div>\n                \n                {(formData.thumbnail_url || thumbnailFile) && (\n                  <div className=\"space-y-2\">\n                    <Label>Current Thumbnail</Label>\n                    <img\n                      src={thumbnailFile ? URL.createObjectURL(thumbnailFile) : formData.thumbnail_url}\n                      alt=\"Current thumbnail\"\n                      className=\"h-32 w-full rounded object-cover\"\n                    />\n                  </div>\n                )}\n              </div>\n            </div>\n\n            {/* Tags */}\n            <div className=\"space-y-4\">\n              <Label>Tags * (SEO Keywords)</Label>\n              \n              <div className=\"flex space-x-2\">\n                <Input\n                  value={newTag}\n                  onChange={(e) => setNewTag(e.target.value)}\n                  placeholder=\"Add a tag\"\n                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}\n                  disabled={isUploading}\n                />\n                <Button type=\"button\" onClick={addTag} disabled={isUploading}>\n                  <Plus className=\"h-4 w-4\" />\n                </Button>\n              </div>\n              \n              {/* Popular Tags */}\n              <div className=\"space-y-2\">\n                <Label className=\"text-sm\">Popular Tags (click to add)</Label>\n                <div className=\"flex flex-wrap gap-2\">\n                  {POPULAR_TAGS.map((tag) => (\n                    <Button\n                      key={tag}\n                      type=\"button\"\n                      variant=\"outline\"\n                      size=\"sm\"\n                      onClick={() => addPopularTag(tag)}\n                      disabled={formData.tags.includes(tag) || isUploading}\n                      className=\"h-7 text-xs\"\n                    >\n                      {tag}\n                    </Button>\n                  ))}\n                </div>\n              </div>\n              \n              {/* Current Tags */}\n              {formData.tags.length > 0 && (\n                <div className=\"space-y-2\">\n                  <Label className=\"text-sm\">Current Tags</Label>\n                  <div className=\"flex flex-wrap gap-2\">\n                    {formData.tags.map((tag) => (\n                      <Badge key={tag} variant=\"secondary\" className=\"pr-1\">\n                        {tag}\n                        <button\n                          type=\"button\"\n                          onClick={() => removeTag(tag)}\n                          className=\"ml-1 hover:text-red-600\"\n                          disabled={isUploading}\n                        >\n                          <X className=\"h-3 w-3\" />\n                        </button>\n                      </Badge>\n                    ))}\n                  </div>\n                </div>\n              )}\n              \n              {errors.tags && <p className=\"text-sm text-red-600\">{errors.tags}</p>}\n            </div>\n\n            {/* Video Details */}\n            <div className=\"grid gap-4 md:grid-cols-3\">\n              <div className=\"space-y-2\">\n                <Label htmlFor=\"duration\">Duration (seconds)</Label>\n                <Input\n                  id=\"duration\"\n                  type=\"number\"\n                  value={formData.duration}\n                  onChange={(e) => handleInputChange('duration', parseInt(e.target.value) || 0)}\n                  placeholder=\"3600\"\n                  disabled={isUploading}\n                />\n              </div>\n              \n              <div className=\"space-y-2\">\n                <Label htmlFor=\"views\">View Count</Label>\n                <Input\n                  id=\"views\"\n                  type=\"number\"\n                  value={formData.view_count}\n                  onChange={(e) => handleInputChange('view_count', parseInt(e.target.value) || 0)}\n                  placeholder=\"0\"\n                  disabled={isUploading}\n                />\n              </div>\n              \n              <div className=\"flex items-center space-x-2 pt-6\">\n                <Switch\n                  id=\"featured\"\n                  checked={formData.featured}\n                  onCheckedChange={(checked) => handleInputChange('featured', checked)}\n                  disabled={isUploading}\n                />\n                <Label htmlFor=\"featured\">Featured Video</Label>\n              </div>\n            </div>\n\n            {/* SEO Preview */}\n            <div className=\"space-y-2\">\n              <Label>SEO Preview</Label>\n              <div className=\"border rounded-lg p-4 bg-slate-50\">\n                <h3 className=\"text-lg font-medium text-blue-600\">{generateSEOTitle()}</h3>\n                <p className=\"text-sm text-slate-600\">{generateSEODescription()}</p>\n                <p className=\"text-xs text-green-600 mt-1\">{window.location.origin}/watch/{video?.id || 'new'}</p>\n              </div>\n            </div>\n\n            {/* Form Actions */}\n            <div className=\"flex justify-end space-x-3 pt-6 border-t\">\n              <Button\n                type=\"button\"\n                variant=\"outline\"\n                onClick={onCancel}\n                disabled={isUploading}\n              >\n                Cancel\n              </Button>\n              <Button\n                type=\"submit\"\n                className=\"bg-red-600 hover:bg-red-700\"\n                disabled={isUploading}\n              >\n                {isUploading ? (\n                  <>\n                    <Loader2 className=\"mr-2 h-4 w-4 animate-spin\" />\n                    {uploadProgress.status === 'uploading' ? 'Uploading...' : 'Processing...'}\n                  </>\n                ) : (\n                  <>\n                    <Upload className=\"mr-2 h-4 w-4\" />\n                    {video ? 'Update Video' : 'Upload Video'}\n                  </>\n                )}\n              </Button>\n            </div>\n          </form>\n        </CardContent>\n      </Card>\n    </div>\n  );\n};\n\nexport default VideoForm;\n"