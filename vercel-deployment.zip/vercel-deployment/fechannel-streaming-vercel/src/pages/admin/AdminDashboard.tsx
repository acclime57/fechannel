import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, Video, BarChart3, Settings, Trash2, Edit, Plus, Play, Download, ExternalLink } from 'lucide-react';
import { VideoForm } from './VideoForm';
import { s3UploadService } from '@/services/s3UploadService';
import { rokuService } from '@/services/rokuService';

interface Video {
  id: string;
  title: string;
  description: string;
  video_url: string;
  thumbnail_url: string;
  category_id: string;
  tags: string[];
  duration: number;
  featured: boolean;
  view_count: number;
  file_size_mb?: number;
  created_at: string;
}

interface UploadProgress {
  video?: number;
  thumbnail?: number;
  status: 'idle' | 'uploading' | 'processing' | 'complete' | 'error';
  message?: string;
}

export const AdminDashboard: React.FC = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [showVideoForm, setShowVideoForm] = useState(false);
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({ status: 'idle' });
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const response = await fetch('/data/videos.json');
      const data = await response.json();
      setVideos(data.videos || []);
    } catch (error) {
      console.error('Error loading videos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVideoUpload = async (videoData: Partial<Video>, videoFile?: File, thumbnailFile?: File) => {
    setUploadProgress({ status: 'uploading', message: 'Preparing upload...' });

    try {
      let videoUrl = videoData.video_url;
      let thumbnailUrl = videoData.thumbnail_url;

      // Upload video file if provided
      if (videoFile) {
        setUploadProgress({ status: 'uploading', video: 0, message: 'Uploading video file...' });
        
        videoUrl = await s3UploadService.uploadVideo(videoFile, (progress) => {
          setUploadProgress(prev => ({ ...prev, video: progress }));
        });
      }

      // Upload thumbnail if provided
      if (thumbnailFile) {
        setUploadProgress(prev => ({ ...prev, status: 'uploading', thumbnail: 0, message: 'Uploading thumbnail...' }));
        
        thumbnailUrl = await s3UploadService.uploadThumbnail(thumbnailFile, (progress) => {
          setUploadProgress(prev => ({ ...prev, thumbnail: progress }));
        });
      }

      setUploadProgress({ status: 'processing', message: 'Processing video data...' });

      // Create new video object
      const newVideo: Video = {
        id: editingVideo?.id || String(Date.now()),
        title: videoData.title || '',
        description: videoData.description || '',
        video_url: videoUrl || '',
        thumbnail_url: thumbnailUrl || '/images/fechannel-logo-v.jpg',
        category_id: videoData.category_id || 'featured',
        tags: videoData.tags || [],
        duration: videoData.duration || 0,
        featured: videoData.featured || false,
        view_count: videoData.view_count || 0,
        file_size_mb: videoFile ? Math.round(videoFile.size / (1024 * 1024) * 100) / 100 : videoData.file_size_mb,
        created_at: videoData.created_at || new Date().toISOString()
      };

      // Update videos list
      if (editingVideo) {
        setVideos(prev => prev.map(v => v.id === editingVideo.id ? newVideo : v));
      } else {
        setVideos(prev => [newVideo, ...prev]);
      }

      // Update Roku feed
      await rokuService.updateFeed([...videos, newVideo]);

      setUploadProgress({ status: 'complete', message: 'Video uploaded successfully!' });
      setShowVideoForm(false);
      setEditingVideo(null);

      // Reset form after delay
      setTimeout(() => {
        setUploadProgress({ status: 'idle' });
      }, 3000);

    } catch (error) {
      console.error('Upload error:', error);
      setUploadProgress({ 
        status: 'error', 
        message: error instanceof Error ? error.message : 'Upload failed' 
      });
    }
  };

  const handleDeleteVideo = async (videoId: string) => {
    if (!confirm('Are you sure you want to delete this video?')) return;

    try {
      const updatedVideos = videos.filter(v => v.id !== videoId);
      setVideos(updatedVideos);
      
      // Update Roku feed
      await rokuService.updateFeed(updatedVideos);
      
      alert('Video deleted successfully!');
    } catch (error) {
      console.error('Delete error:', error);
      alert('Failed to delete video');
    }
  };

  const formatFileSize = (mb?: number) => {
    if (!mb) return 'Unknown';
    if (mb < 1000) return `${mb} MB`;
    return `${(mb / 1000).toFixed(1)} GB`;
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  return (
    <div className=\"min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6\">
      <div className=\"mx-auto max-w-7xl\">
        {/* Header */}
        <div className=\"mb-8 flex items-center justify-between\">
          <div>
            <h1 className=\"text-3xl font-bold text-slate-900\">FEChannel Admin Dashboard</h1>
            <p className=\"text-slate-600\">Manage your streaming content and analytics</p>
          </div>
          <Button 
            onClick={() => setShowVideoForm(true)}
            className=\"bg-red-600 hover:bg-red-700\"
          >
            <Plus className=\"mr-2 h-4 w-4\" />
            Add Video
          </Button>
        </div>

        {/* Upload Progress */}
        {uploadProgress.status !== 'idle' && (
          <Card className=\"mb-6 border-l-4 border-l-blue-500\">
            <CardContent className=\"pt-6\">
              <div className=\"flex items-center justify-between\">
                <div>
                  <p className=\"font-medium\">{uploadProgress.message}</p>
                  {uploadProgress.video !== undefined && (
                    <p className=\"text-sm text-slate-600\">Video: {uploadProgress.video}%</p>
                  )}
                  {uploadProgress.thumbnail !== undefined && (
                    <p className=\"text-sm text-slate-600\">Thumbnail: {uploadProgress.thumbnail}%</p>
                  )}
                </div>
                <Badge variant={uploadProgress.status === 'error' ? 'destructive' : 'default'}>
                  {uploadProgress.status}
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className=\"grid w-full grid-cols-4\">
            <TabsTrigger value=\"overview\">Overview</TabsTrigger>
            <TabsTrigger value=\"videos\">Videos ({videos.length})</TabsTrigger>
            <TabsTrigger value=\"analytics\">Analytics</TabsTrigger>
            <TabsTrigger value=\"settings\">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value=\"overview\" className=\"space-y-6\">
            <div className=\"grid gap-6 md:grid-cols-2 lg:grid-cols-4\">
              <Card>
                <CardHeader className=\"flex flex-row items-center justify-between space-y-0 pb-2\">
                  <CardTitle className=\"text-sm font-medium\">Total Videos</CardTitle>
                  <Video className=\"h-4 w-4 text-muted-foreground\" />
                </CardHeader>
                <CardContent>
                  <div className=\"text-2xl font-bold\">{videos.length}</div>
                  <p className=\"text-xs text-muted-foreground\">
                    {videos.filter(v => v.featured).length} featured
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className=\"flex flex-row items-center justify-between space-y-0 pb-2\">
                  <CardTitle className=\"text-sm font-medium\">Total Views</CardTitle>
                  <BarChart3 className=\"h-4 w-4 text-muted-foreground\" />
                </CardHeader>
                <CardContent>
                  <div className=\"text-2xl font-bold\">
                    {videos.reduce((acc, v) => acc + v.view_count, 0).toLocaleString()}
                  </div>
                  <p className=\"text-xs text-muted-foreground\">Across all content</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className=\"flex flex-row items-center justify-between space-y-0 pb-2\">
                  <CardTitle className=\"text-sm font-medium\">Content Size</CardTitle>
                  <Upload className=\"h-4 w-4 text-muted-foreground\" />
                </CardHeader>
                <CardContent>
                  <div className=\"text-2xl font-bold\">
                    {formatFileSize(videos.reduce((acc, v) => acc + (v.file_size_mb || 0), 0))}
                  </div>
                  <p className=\"text-xs text-muted-foreground\">Total storage used</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className=\"flex flex-row items-center justify-between space-y-0 pb-2\">
                  <CardTitle className=\"text-sm font-medium\">Roku Feed</CardTitle>
                  <ExternalLink className=\"h-4 w-4 text-muted-foreground\" />
                </CardHeader>
                <CardContent>
                  <div className=\"text-2xl font-bold text-green-600\">Live</div>
                  <p className=\"text-xs text-muted-foreground\">Auto-updating</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common administrative tasks</CardDescription>
              </CardHeader>
              <CardContent className=\"space-y-4\">
                <div className=\"grid gap-4 md:grid-cols-2\">
                  <Button 
                    variant=\"outline\" 
                    className=\"justify-start\"
                    onClick={() => window.open('/roku-feed.json', '_blank')}
                  >
                    <Download className=\"mr-2 h-4 w-4\" />
                    Download Roku Feed
                  </Button>
                  <Button 
                    variant=\"outline\" 
                    className=\"justify-start\"
                    onClick={() => rokuService.updateFeed(videos)}
                  >
                    <Settings className=\"mr-2 h-4 w-4\" />
                    Regenerate Roku Feed
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Videos Tab */}
          <TabsContent value=\"videos\" className=\"space-y-6\">
            <div className=\"grid gap-6\">
              {loading ? (
                <Card>
                  <CardContent className=\"pt-6\">
                    <p className=\"text-center text-slate-600\">Loading videos...</p>
                  </CardContent>
                </Card>
              ) : videos.length === 0 ? (
                <Card>
                  <CardContent className=\"pt-6\">
                    <p className=\"text-center text-slate-600\">No videos found. Upload your first video!</p>
                  </CardContent>
                </Card>
              ) : (
                videos.map((video) => (
                  <Card key={video.id} className=\"overflow-hidden\">
                    <CardContent className=\"p-6\">
                      <div className=\"flex items-start space-x-4\">
                        <img
                          src={video.thumbnail_url}
                          alt={video.title}
                          className=\"h-20 w-32 rounded-lg object-cover\"
                        />
                        <div className=\"min-w-0 flex-1\">
                          <div className=\"flex items-start justify-between\">
                            <div>
                              <h3 className=\"text-lg font-semibold text-slate-900\">{video.title}</h3>
                              <p className=\"text-sm text-slate-600 line-clamp-2\">{video.description}</p>
                              <div className=\"mt-2 flex flex-wrap gap-2\">
                                <Badge variant=\"secondary\">{video.category_id}</Badge>
                                {video.featured && <Badge className=\"bg-red-100 text-red-800\">Featured</Badge>}
                                <Badge variant=\"outline\">{formatDuration(video.duration)}</Badge>
                                <Badge variant=\"outline\">{formatFileSize(video.file_size_mb)}</Badge>
                                <Badge variant=\"outline\">{video.view_count.toLocaleString()} views</Badge>
                              </div>
                            </div>
                            <div className=\"flex space-x-2\">
                              <Button
                                size=\"sm\"
                                variant=\"outline\"
                                onClick={() => window.open(video.video_url, '_blank')}
                              >
                                <Play className=\"h-4 w-4\" />
                              </Button>
                              <Button
                                size=\"sm\"
                                variant=\"outline\"
                                onClick={() => {
                                  setEditingVideo(video);
                                  setShowVideoForm(true);
                                }}
                              >
                                <Edit className=\"h-4 w-4\" />
                              </Button>
                              <Button
                                size=\"sm\"
                                variant=\"outline\"
                                onClick={() => handleDeleteVideo(video.id)}
                              >
                                <Trash2 className=\"h-4 w-4\" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value=\"analytics\" className=\"space-y-6\">
            <Card>
              <CardHeader>
                <CardTitle>Content Analytics</CardTitle>
                <CardDescription>Performance metrics for your content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className=\"space-y-4\">
                  <div>
                    <h4 className=\"font-medium mb-2\">Top Performing Videos</h4>
                    {videos
                      .sort((a, b) => b.view_count - a.view_count)
                      .slice(0, 5)
                      .map((video, index) => (
                        <div key={video.id} className=\"flex items-center justify-between py-2\">
                          <span className=\"text-sm\">{index + 1}. {video.title}</span>
                          <Badge variant=\"outline\">{video.view_count.toLocaleString()} views</Badge>
                        </div>
                      ))}
                  </div>
                  
                  <div>
                    <h4 className=\"font-medium mb-2\">Content by Category</h4>
                    {Object.entries(
                      videos.reduce((acc, video) => {
                        acc[video.category_id] = (acc[video.category_id] || 0) + 1;
                        return acc;
                      }, {} as Record<string, number>)
                    ).map(([category, count]) => (
                      <div key={category} className=\"flex items-center justify-between py-2\">
                        <span className=\"text-sm capitalize\">{category}</span>
                        <Badge variant=\"outline\">{count} videos</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value=\"settings\" className=\"space-y-6\">
            <Card>
              <CardHeader>
                <CardTitle>S3 Configuration</CardTitle>
                <CardDescription>AWS S3 bucket settings for video storage</CardDescription>
              </CardHeader>
              <CardContent className=\"space-y-4\">
                <div className=\"grid gap-4 md:grid-cols-2\">
                  <div>
                    <label className=\"text-sm font-medium\">Bucket Name</label>
                    <p className=\"text-sm text-slate-600\">fechannel-videos</p>
                  </div>
                  <div>
                    <label className=\"text-sm font-medium\">Region</label>
                    <p className=\"text-sm text-slate-600\">us-east-1</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Roku Integration</CardTitle>
                <CardDescription>Roku channel feed configuration</CardDescription>
              </CardHeader>
              <CardContent className=\"space-y-4\">
                <div>
                  <label className=\"text-sm font-medium\">Feed URL</label>
                  <p className=\"text-sm text-slate-600 break-all\">{window.location.origin}/roku-feed.json</p>
                </div>
                <Button
                  variant=\"outline\"
                  onClick={() => rokuService.updateFeed(videos)}
                >
                  <Settings className=\"mr-2 h-4 w-4\" />
                  Update Roku Feed
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Video Form Modal */}
        {showVideoForm && (
          <VideoForm
            video={editingVideo}
            onSubmit={handleVideoUpload}
            onCancel={() => {
              setShowVideoForm(false);
              setEditingVideo(null);
            }}
            uploadProgress={uploadProgress}
          />
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
